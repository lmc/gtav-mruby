TELEPORT_LOCATIONS["locations.0.heading"] = 0.0
TELEPORT_LOCATIONS["locations.0.name"] = "World Origin"
TELEPORT_LOCATIONS["locations.0.x"] = 0.0
TELEPORT_LOCATIONS["locations.0.y"] = 0.0
TELEPORT_LOCATIONS["locations.0.z"] = 0.0
