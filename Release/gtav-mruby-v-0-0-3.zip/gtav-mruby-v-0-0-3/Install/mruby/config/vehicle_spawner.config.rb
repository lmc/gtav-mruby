VEHICLE_SPAWNER["favourites.0.data"] = {:model=>"bullet"}
VEHICLE_SPAWNER["favourites.0.name"] = "Test"
