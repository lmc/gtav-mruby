CONFIG["console.enabled"] = false

CONFIG["console.game.x"] = 0
CONFIG["console.game.y"] = 0
CONFIG["console.game.w"] = 1280 + 4
CONFIG["console.game.h"] = 720 + 25

CONFIG["console.x"] = 1280 + 4
CONFIG["console.y"] = 0
CONFIG["console.w"] = 650
CONFIG["console.h"] = 720 + 25

CONFIG["console.remote.enabled"] = false

CONFIG["scripts.RuntimeMetrics.enabled"] = true
